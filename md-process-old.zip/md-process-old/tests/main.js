import {expect} from 'chai';
import processor from '../lib/process';
import Stream from 'stream';

describe('md-process', () => {
    context('provides a main-entry module', () => {
        it('that is a function', () => {
            expect(processor).to.be.a('function');
        }); 
    })

    context('main-entry function', () => {
        context('when invoked with a string', () => {
            it('transforms it to HTML', () => {
                const result1 = processor('').trim();
                expect(result1).to.be.a('string');
                expect(result1).to.be.empty;

                const result2 = processor('# Heading').trim();
                expect(result2).to.be.a('string');
                expect(result2).to.equal('<h1 id="heading">Heading</h1>');
            });
        });
    });
});