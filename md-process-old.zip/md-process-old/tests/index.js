/**
Mocha tests bootstrap/entry point. Injects Babel to process the **following** modules
written in ES6.
**/
require('babel-core/register')({
    presets: ['es2015']
});
require('./main');