# md-process

The main purpose of the md-process module is to provide a highly configurable and customizable abstraction over processing of Markdown files into HTML, mainly for use in documentation generation scenarious.

## md-process changelog

### 0.0.2

Restoration of the package

### 0.0.1

Initial publish and commit